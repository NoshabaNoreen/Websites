#print int
x = 5
print(x)
#print float
y = 5.5
print(y)
print (type(y))
print(19/4)
print(19//4)
#type casting
print(int(4.75))
#print false
bool(0)
#print true
bool('False')

#print string (string may be in single quote or double quotes)
name ="Noshaba"
print(name)
#Print type of variable
print (type(x))
#Concate two strings
print('Noshaba ' + ' Noreen')

name = 'Noshaba Noreen'
#last wala character show hoga
print(name[-1])
#1st 10 character show hongy
print(name[:10])
#1st 9 chor k last waly sary character print hongy
print(name[9:])

#string Formatting
a=5
print('my val is ' + str(a))
#formatting string (another method)
print(f'my val is  + {a}')
#Multiline string
s = ''' This is machine learning class, and we are learning python!'''
print(s)

#return true (Boolean data type)
print(5==5)
print(2+3)
print(5%2)
#to print the string for 20 times
print('@' * 20)
#Comparison operators
print(4<5)
print(5<4)
print(4!=3)
#Logical operators
print(4<5 or 5<5)
print(2+3 and 5+5)
#make arrays (in- membership operator used for check whether the number is present or not)
mylist =[1,2,3,4,5]
print(10 in mylist)
#search a word in string 
print('cat' in 'my concatenated list')
#if mein agr condition glt ho gi tu statement run nhi ho gi
if 4<5:
    print("Four is less than five")
#control flow (condition true nhi hai ab sirf hello world print hoga)
if 4>5:
    print("Four is less than five")
print('Hello World')
#if else
if 4>5:
    print("Four is less than five")
else:
    print("Four is greater than five")
#if else if 
marks = 85
if marks>90:
    print("A Grade")
elif marks > 80:
    print("B Grade")
else:
    print("C Grade")

#Loops
a = [1,2,3,4,5]
for i in a:
    print(i)
#print value on index 0 that is 1
print(a[0])
#set 10 on 1 index:
a[1] = 10
print(a)
#while loop
b=3
while(b<=5):
   print(b)
   b = b+1
#Functions
def multiplybythree(val):
    return val*3
print(multiplybythree(10))
#function ko simplify kr diya
def multiply(val1, val2):
    return val1*val2
print(multiply(5,5))

#To print slice of index
mylist = [1,2,3,4,5]
print (mylist[-2:])
#to multiply list by 5:
mynewlist=[x*5 for x in mylist]
print(mynewlist)
#list comprehension(ek list pr koi operation perform kr k unhein ur list mein convert krna hai)
# for n in mylist:
#     mynewlist.append(n*5)
# print(mynewlist)
#Dictionary
fruits = {
    'a' : 'apple',
    'b' : 'banana'
}
#print all
print(fruits)
#print specific
print(fruits['a'])
#add another data in fruits array
fruits['m'] = 'mango'
print(fruits)


#keys
# fruits.key()
# dict_key(['a', 'b','m',0])
# fruits.values()
# dict_key(['apple', 'banana','mango','mango'])
# print(fruits.get('c','not found'))

#fruits_names = list


students ={
    'Ali' : [80,90],
    1 : [76,56]
}
print(students[1])

students ={
    'Ali' : [80,90],
    'Imran': [76,56]
}
#add another value in ali key
students['Ali'].append(90)
print(students)

del students['Imran'][1]
print(students)
#built in libaray
from math import sqrt
#import one function from entire libaray
print(sqrt(16))
#import one function from entire libaray
#pip install numpy , phr yeh command chly gi
# import numpy as np
# mylist =[1,2,3,4,5]
# my_array=np.array(mylist)
# print(my_array)

#print(my_array*5)
def knn(x2,x1,y2,y1):
    return(sqrt((x2-x1)**2 +(y2-y1)**2))
print(knn(1,3,5,4))
#another method
x2=2
x1=4
y2=3
y1=5
print(sqrt((x2-x1)**2 +(y2-y1)**2))
#csv(comma separated value) file
# import pandas as pd
# train_data = pd.read_csv('knnData_train.csv')
# print(train_data)
#print(len(train_data),len(test_data))
#to print the top record
#train_data.head(10)

from matplotlib import pyplot as plt import seaborn as sns
sns.scatterplot(data=train_data,x = 'feature_1',y ='feature2','hue'='class')
def calc_distance(train_f2,test_f2,test_f3)
return sqrt(train_f1 - test_f1* )
print(calc_distance(2,3,4,5))
first_row = test_data.iloc[0]
print(fisrt_row)
#loop
for idx , row in train_data.iterrows():
     print(row)

    train_f1 = row['feature_1']
     train_f2 = row['feature_2']
     print(train_f1,train_f2)
   






