from django.shortcuts import render
from .models import home  # Import the model to store data in the database (if needed)
from django.http import HttpResponse

def contact(request):
    if request.method == "POST":
        # Retrieve form data
        name = request.POST.get('name')
        email = request.POST.get('email')
        message = request.POST.get('message')
       
        # Print data to console (optional for debugging)
        print(f"Name: {name}, Email: {email}, Message: {message}")

        # Save to database if necessary
        ins= home(name=name, email=email, message=message )
        ins.save()

        # Pass a success message back to the template
        return render(request, 'myapp/home.html', {'success': True})
    
    # Render the home template for GET requests
    return render(request, 'myapp/home.html')

