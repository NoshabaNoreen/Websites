from django.contrib import admin
from .models import home

# Register your model
admin.site.register(home)
